"use strict";

/****************************************************************
 GeoForest Enterprise Portal
****************************************************************/

document.addEventListener("DOMContentLoaded", () => {

    initializePortal();

});

/****************************************************************
 INITIALIZE
****************************************************************/

function initializePortal() {

    registerMenuEvents();

    loadPage("dashboard.html");

}

/****************************************************************
 MENU EVENTS
****************************************************************/

function registerMenuEvents() {

    document
        .querySelectorAll(".sidebar a")
        .forEach(link => {

            link.addEventListener("click", function (e) {

                e.preventDefault();

                document
                    .querySelectorAll(".sidebar a")
                    .forEach(a => a.classList.remove("active"));

                this.classList.add("active");

                const page =
                    this.dataset.page;

                if (page)
                    loadPage(page);

            });

        });

}

/****************************************************************
LOAD PAGE
****************************************************************/

async function loadPage(page) {

    try {

        const response = await fetch("html/" + page);

        if (!response.ok)
            throw new Error("Unable to load " + page);

        const html = await response.text();

        document.getElementById("content").innerHTML = html;

        requestAnimationFrame(async () => {

            switch (page) {

                case "dashboard.html":

                    if (typeof initializeDashboard === "function")
                        await initializeDashboard();

                    break;

                case "plant_species.html":

                    if (typeof initializePlantSpecies === "function")
                        await initializePlantSpecies();

                    break;

                case "plant_inventory.html":

                    if (typeof initializePlantInventory === "function")
                        await initializePlantInventory();

                    break;

                case "forest_divisions.html":

                    if (typeof initializeForestDivisions === "function")
                        await initializeForestDivisions();

                    break;

                case "forest_ranges.html":

                    if (typeof initializeForestRanges === "function")
                        await initializeForestRanges();

                    break;

                case "forest_beats.html":

                    if (typeof initializeForestBeats === "function")
                        await initializeForestBeats();

                    break;

            }

        });

    }

    catch (error) {

        document.getElementById("content").innerHTML =

            `<div class="alert alert-danger">

            ${error.message}

        </div>`;

    }

}


/****************************************************************
 LOGOUT
****************************************************************/

function logout() {

    if (!confirm("Do you want to logout?"))
        return;

    window.location.href = "login.html";

}